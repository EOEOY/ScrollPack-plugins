from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
import json


def decrypt_copy_manga(encrypted_str: str, key_str: str) -> dict | list:
    iv = encrypted_str[:16].encode("ascii")
    data = bytes.fromhex(encrypted_str[16:])
    key = key_str.encode("ascii").ljust(16, b"\x00")
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    decryptor = cipher.decryptor()
    plaintext = decryptor.update(data) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    plaintext = unpadder.update(plaintext) + unpadder.finalize()
    return json.loads(plaintext.decode("utf-8"))
