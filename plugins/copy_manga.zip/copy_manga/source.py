import re
import asyncio
from typing import List
from urllib.parse import urljoin, urlparse

from plugins.base import BrowserSource
from plugins.copy_manga.decrypt import decrypt_copy_manga
from utils.http_util import http_get_bytes
from models import Novel, Catalog, Volume, Chapter
from logger import logger
from config import AppConfig
from scheduler import Scheduler


class CopyMangaSource(BrowserSource):
    _URL_PAT = re.compile(
        r"(?:copy|mangacopy|copymanga)\.[^/]+/comic/([a-zA-Z0-9_-]+)"
    )

    _cct: str = ""
    _domain: str = ""

    @property
    def name(self) -> str:
        return "\u62f7\u8d1d\u6f2b\u753b"

    @property
    def source_url(self) -> str:
        return self._domain or "https://www.2026copy.com"

    def support_url(self, url: str) -> bool:
        return bool(self._URL_PAT.search(url))

    def _get_path_word(self, url: str) -> str:
        m = self._URL_PAT.search(url)
        if not m:
            raise ValueError(f"Unsupported url: {url}")
        return m.group(1)

    def _get_domain(self, url: str) -> str:
        parsed = urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}"

    async def get_novel(self, url: str):
        self._domain = self._get_domain(url)
        path_word = self._get_path_word(url)
        novel = Novel()
        novel.url = url
        novel.id = path_word

        if not await self._safe_goto(
            f"{self._domain}/comic/{path_word}", wait_until="domcontentloaded"
        ):
            raise RuntimeError(f"Failed to load novel page: {url}")

        await self._human_delay(1, 2)

        novel.title = await self._page.eval_on_selector(
            ".comicParticulars-title-right h6",
            "el => el ? el.textContent.trim() || el.getAttribute('title') || '' : ''",
        )
        if not novel.title:
            title = await self._page.evaluate("document.title || ''")
            parts = title.rsplit(" - ", 2)
            novel.title = parts[0].strip() if parts else path_word

        novel.author = await self._page.eval_on_selector(
            'a[href*="/author/"]',
            'el => el ? el.textContent.trim() : ""',
        )
        if not novel.author:
            novel.author = "\u672a\u77e5"

        novel.cover_url = None
        cover = await self._page.eval_on_selector(
            ".comicParticulars-left-img img",
            'el => el ? (el.getAttribute("src") || el.getAttribute("data-src") || "") : ""',
        )
        if cover:
            novel.cover_url = urljoin(self._domain, cover)

        novel.tags = await self._page.eval_on_selector_all(
            ".comicParticulars-tag a",
            "els => els.map(el => el.textContent.trim()).filter(t => t)",
        )

        novel.publisher = "\u62f7\u8d1d\u6f2b\u753b"
        novel.status = ""
        novel.description = novel.title

        cct = await self._page.evaluate("window.ccz || ''")
        if cct:
            self._cct = cct

        return novel

    async def get_novel_catalog(self, novel):
        path_word = novel.id
        catalog = Catalog(novel)
        catalog = await self._crawl_chapters(path_word, catalog)
        return catalog

    async def _crawl_chapters(self, path_word: str, catalog: Catalog) -> Catalog:
        await self._ensure_page()

        if not await self._safe_goto(
            f"{self._domain}/comic/{path_word}", wait_until="domcontentloaded"
        ):
            logger.warning("Failed to load detail page, catalog empty")
            return catalog

        try:
            await self._page.wait_for_selector(".upLoop .table-default", timeout=30000)
        except Exception:
            pass
        await asyncio.sleep(2)

        # Extract chapters from tab-panes, using tab label as volume name
        groups = await self._page.evaluate("""() => {
            const upLoop = document.querySelector('.upLoop');
            if (!upLoop) return [];
            const groups = [];
            let currentGroup = '默认';

            for (const node of upLoop.children) {
                if (node.tagName === 'SPAN') {
                    currentGroup = node.textContent.trim();
                } else if (node.classList.contains('table-default')) {
                    // Get tab -> chapters mapping from each tab-pane
                    const tabs = node.querySelectorAll('.nav-tabs .nav-link');
                    const panes = node.querySelectorAll('.tab-content > .tab-pane');
                    for (let i = 0; i < tabs.length; i++) {
                        const tabLabel = tabs[i].textContent.trim();
                        if (tabLabel === '全部') continue; // skip "all" tab, duplicates content
                        const pane = panes[i];
                        if (!pane) continue;
                        const links = pane.querySelectorAll('a[href*="/chapter/"]');
                        const chapters = [];
                        for (const a of links) {
                            const text = a.textContent.trim();
                            if (text) chapters.push({href: a.href, text: text});
                        }
                        if (chapters.length > 0) {
                            const volName = currentGroup === '默认' ? tabLabel : currentGroup + '·' + tabLabel;
                            groups.push({name: volName, chapters: chapters});
                        }
                    }
                }
            }
            return groups;
        }""")

        if groups:
            for g in groups:
                volume = Volume(g["name"], catalog)
                for ch in g["chapters"]:
                    volume.chapters.append(Chapter(ch["text"], ch["href"], volume))
                if volume.chapters:
                    catalog.volumes.append(volume)
            total = sum(len(v.chapters) for v in catalog.volumes)
            names = [v.volume_name for v in catalog.volumes]
            logger.info(f"Extracted {total} chapters in {len(catalog.volumes)} volumes: {names}")
            return catalog

        logger.info("Chapter list not rendered, falling back to page-by-page crawl...")

        first_uuid = None
        all_chapter_hrefs = await self._page.eval_on_selector_all(
            'a[href*="/chapter/"]',
            """els => els
                .filter(el => {
                    const cls = el.className || '';
                    const parentCls = (el.parentElement && el.parentElement.className) || '';
                    return !cls.includes('btn') && !parentCls.includes('comicParticulars-botton');
                })
                .map(el => el.href)
            """,
        )
        if all_chapter_hrefs:
            first_href = all_chapter_hrefs[0]
            uuid_match = re.search(r"/chapter/([a-f0-9-]+)", first_href)
            if uuid_match:
                first_uuid = uuid_match.group(1)

        if not first_uuid:
            return catalog

        volume = Volume("\u9ed8\u8ba4", catalog)
        url = f"{self._domain}/comic/{path_word}/chapter/{first_uuid}"
        seen = set()
        max_chapters = 500

        while url and len(seen) < max_chapters:
            uid_match = re.search(r"/chapter/([a-f0-9-]+)", url)
            if not uid_match:
                break
            uid = uid_match.group(1)
            if uid in seen:
                break
            seen.add(uid)

            if not await self._safe_goto(url, wait_until="domcontentloaded"):
                logger.warning(
                    f"Failed to load chapter after retries, stopping crawl"
                )
                break
            await asyncio.sleep(random.uniform(2, 4))

            title = await self._page.evaluate("document.title || ''")
            title = title.split(" - ")[0].strip() if title else f"chapter {len(seen)}"

            chapter = Chapter(title, url, volume)
            volume.chapters.append(chapter)

            logger.info(f"  Crawled [{len(seen)}] {title[:40]}")

            next_href = await self._page.eval_on_selector(
                ".comicContent-next a",
                'el => el ? el.getAttribute("href") || "" : ""',
            )
            if next_href and next_href != "#" and next_href != "":
                url = (
                    urljoin(self._domain, next_href)
                    if not next_href.startswith("http")
                    else next_href
                )
            else:
                url = None

        if volume.chapters:
            catalog.volumes.append(volume)

        return catalog

    async def get_novel_chapter(self, chapter) -> str:
        return ""

    async def get_image(self, src: str) -> bytes:
        if not src.startswith("http"):
            src = urljoin(self._domain, src)

        # 1. httpx with proxy + retries
        for attempt in range(8):
            try:
                data = await http_get_bytes(
                    src,
                    headers={
                        "Referer": self._domain,
                        "Accept": "image/webp,image/*,*/*;q=0.8",
                    },
                    timeout=20,
                    max_attempts=1,
                )
                if data:
                    return data
            except Exception:
                pass
            if attempt < 7:
                await asyncio.sleep(1.5)

        # 2. Playwright fetch as last resort
        try:
            await self._ensure_page()
            data = await self._page.evaluate(
                """async (url) => {
                    const r = await fetch(url, {referrer: document.location.href, mode:'no-cors'});
                    const buf = await r.arrayBuffer();
                    return Array.from(new Uint8Array(buf));
                }""",
                src,
            )
            if data:
                return bytes(data)
        except Exception:
            pass

        logger.warning(f"Failed to download: {src[:100]}")
        return b""

    async def fetch_chapter_images(self, chapter_url: str) -> List[str]:
        logger.info(f"Loading chapter: {chapter_url}")
        if not await self._safe_goto(chapter_url, wait_until="domcontentloaded"):
            return []

        await asyncio.sleep(2)

        # Read cct from chapter page for contentKey decryption
        cct = await self._page.evaluate("window.cct || ''")
        if cct:
            self._cct = cct

        # 1. Try contentKey decryption (instant, ordered, all URLs)
        ck = await self._page.evaluate("window.contentKey || ''")
        if ck and self._cct:
            try:
                decrypted = decrypt_copy_manga(ck, self._cct)
                if isinstance(decrypted, list):
                    urls = [item["url"] for item in decrypted if isinstance(item, dict) and "url" in item]
                    if urls:
                        logger.info(f"  Decrypted {len(urls)} images from contentKey")
                        return urls
            except Exception as e:
                logger.warning(f"contentKey decrypt failed: {e}")

        # 2. Get expected total from page counter
        expected = 0
        try:
            await self._page.wait_for_function(
                """() => {
                    const c = document.querySelector('.comicCount');
                    return c && c.textContent && parseInt(c.textContent) > 0;
                }""",
                timeout=10000,
            )
            expected = await self._page.evaluate("parseInt(document.querySelector('.comicCount').textContent) || 0")
            logger.info(f"  Page counter: {expected} images total")
        except Exception:
            pass

        # 3. Force-load all lazy images and scroll until count matches
        prev = 0
        for attempt in range(10):
            await self._page.evaluate("""
                () => {
                    document.querySelectorAll('img[data-src]').forEach(img => {
                        if (!img.src) img.src = img.getAttribute('data-src');
                    });
                    window.scrollTo(0, document.body.scrollHeight);
                }
            """)
            await asyncio.sleep(2)
            await self._page.evaluate("window.scrollTo(0, 0)")
            await asyncio.sleep(1)

            cur = await self._page.evaluate(
                "document.querySelectorAll('ul.comicContent-list img[src]').length"
            )
            logger.info(f"  scroll attempt {attempt+1}: {cur}/{expected or '?'} images")
            if expected > 0 and cur >= expected:
                break
            if attempt >= 2 and cur == prev and cur > 0:
                break
            prev = cur

        # 4. Collect in DOM order
        img_urls = await self._page.evaluate("""() => {
            const imgs = document.querySelectorAll('ul.comicContent-list img');
            const seen = new Set();
            const result = [];
            for (const img of imgs) {
                const u = img.src || img.getAttribute('data-src') || '';
                if (u && !u.includes('loading') && !u.includes('ads') && !u.includes('static/') && !u.includes('data:') && !seen.has(u)) {
                    seen.add(u);
                    result.push(u);
                }
            }
            return result;
        }""")

        logger.info(f"  Extracted {len(img_urls)} images from DOM (expected: {expected})")
        return img_urls
