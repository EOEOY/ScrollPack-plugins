import re
import asyncio
from typing import List
from urllib.parse import urljoin, urlparse

from plugins.base import BrowserSource
from utils.http_util import http_get_bytes
from models import Novel, Catalog, Volume, Chapter
from logger import logger


class MangabzMangaSource(BrowserSource):
    _URL_PAT = re.compile(r"mangabz\.com/(\d+)bz/")

    _domain: str = ""
    _mid: str = ""

    @property
    def name(self) -> str:
        return "Mangabz\u6f2b\u753b"

    @property
    def source_url(self) -> str:
        return self._domain or "https://www.mangabz.com"

    def support_url(self, url: str) -> bool:
        return bool(self._URL_PAT.search(url))

    def _get_mid(self, url: str) -> str:
        m = self._URL_PAT.search(url)
        if not m:
            raise ValueError(f"Unsupported url: {url}")
        return m.group(1)

    def _get_domain(self, url: str) -> str:
        parsed = urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}"

    async def get_novel(self, url: str):
        self._domain = self._get_domain(url)
        mid = self._get_mid(url)
        self._mid = mid

        detail_url = f"{self._domain}/{mid}bz/"
        if not await self._safe_goto(detail_url, wait_until="domcontentloaded"):
            raise RuntimeError(f"Failed to load novel page: {detail_url}")

        await self._human_delay(1, 2)

        novel = Novel()
        novel.url = url
        novel.id = mid

        novel.title = await self._page.eval_on_selector(
            ".detail-info-title", "el => el ? el.textContent.trim() : ''"
        )
        if not novel.title:
            t = await self._page.evaluate("document.title || ''")
            parts = t.split("_")
            novel.title = parts[0].strip() if parts else mid

        cover = await self._page.eval_on_selector(
            ".detail-info-cover",
            'el => el ? (el.src || "") : ""',
        )
        if cover:
            novel.cover_url = urljoin(self._domain, cover)

        author_els = await self._page.eval_on_selector_all(
            ".detail-info-tip > span:first-child a",
            "els => els.map(el => el.textContent.trim())",
        )
        novel.author = ", ".join(author_els) if author_els else "\u672a\u77e5"

        status_el = await self._page.eval_on_selector(
            ".detail-info-tip > span:nth-child(2) span",
            'el => el ? el.textContent.trim() : ""',
        )
        novel.status = status_el or ""

        novel.tags = await self._page.eval_on_selector_all(
            ".detail-info-tip .item",
            "els => els.map(el => el.textContent.trim()).filter(t => t)",
        )

        desc = await self._page.eval_on_selector(
            ".detail-info-content",
            "el => el ? el.textContent.trim() : ''",
        )
        novel.description = desc or novel.title

        novel.publisher = "Mangabz"

        return novel

    async def get_novel_catalog(self, novel):
        mid = novel.id
        detail_url = f"{self._domain}/{mid}bz/"

        await self._ensure_page()
        if not await self._safe_goto(detail_url, wait_until="domcontentloaded"):
            logger.warning("Failed to load detail page for catalog")
            return Catalog(novel)

        await asyncio.sleep(1)

        raw = await self._page.eval_on_selector_all(
            "#chapterlistload a.detail-list-form-item",
            """els => els.map(el => {
                return {href: el.href, text: el.textContent.trim()};
            })""",
        )

        catalog = Catalog(novel)
        if raw:
            volume = Volume("\u9ed8\u8ba4", catalog)
            for link in raw:
                name = link.get("text") or ""
                href = link.get("href", "")
                if not name or not href:
                    continue
                name = re.sub(r"\s*\(\d+P\)\s*", "", name).strip()
                volume.chapters.append(Chapter(name, href, volume))
            if volume.chapters:
                catalog.volumes.append(volume)
                logger.info(f"Extracted {len(volume.chapters)} chapters")

        return catalog

    async def get_novel_chapter(self, chapter) -> str:
        return ""

    async def fetch_chapter_images(self, chapter_url: str) -> List[str]:
        logger.info(f"Loading chapter: {chapter_url}")

        base_url = chapter_url.rstrip("/")

        if not await self._safe_goto(base_url + "/", wait_until="domcontentloaded"):
            return []

        # --- step 1: read total image count from page JS globals ---
        try:
            image_count = await self._page.evaluate("MANGABZ_IMAGE_COUNT || 1")
            image_count = int(image_count)
        except Exception:
            image_count = 1
        logger.info(f"  Total pages: {image_count}")

        _WAIT_REAL_IMAGE = """() => {
            const img = document.getElementById('cp_image');
            if (!img) return false;
            const src = img.src || '';
            if (!src || src.startsWith('data:')) return false;
            if (src.includes('loading') || src.includes('css.mangabz.com/images/')) return false;
            if (!img.complete) return false;
            if (img.naturalWidth === 0) return false;
            return true;
        }"""

        img_urls = []

        for page in range(1, image_count + 1):
            if page > 1:
                page_url = base_url + "-p" + str(page) + "/"
                if not await self._safe_goto(page_url, wait_until="domcontentloaded"):
                    logger.warning(f"  Failed to load page {page}")
                    continue
                await asyncio.sleep(2)

            # Wait for real image (not loading GIF placeholder)
            try:
                await self._page.wait_for_function(_WAIT_REAL_IMAGE, timeout=60000)
            except Exception:
                logger.warning(f"  Timed out waiting for image on page {page}")
                # fallback: try once more with sleep
                await asyncio.sleep(5)

            src = await self._page.evaluate("""() => {
                const img = document.getElementById('cp_image');
                return img ? img.src : '';
            }""")

            if src and "loading" not in src.lower() and "css.mangabz.com/images/" not in src:
                img_urls.append(src)
                if page % 10 == 0:
                    logger.info(f"  Progress: {page}/{image_count}")
            else:
                logger.warning(f"  Skipped page {page}: src={src[:80] if src else 'none'}")

        logger.info(f"  Collected {len(img_urls)} images (expecting {image_count})")
        return img_urls

    async def get_image(self, src: str) -> bytes:
        if not src.startswith("http"):
            src = urljoin(self._domain, src)

        for _ in range(5):
            try:
                data = await http_get_bytes(
                    src,
                    headers={
                        "Referer": self._domain,
                        "Accept": "image/webp,image/*,*/*;q=0.8",
                    },
                    timeout=30,
                    max_attempts=1,
                )
                if data:
                    return data
            except Exception:
                pass
            await asyncio.sleep(1.5)

        logger.warning(f"Failed to download: {src[:100]}")
        return b""
